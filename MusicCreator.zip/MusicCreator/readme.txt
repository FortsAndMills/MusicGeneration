Requirements:
- mido
- PyTorch

Run create_music.py