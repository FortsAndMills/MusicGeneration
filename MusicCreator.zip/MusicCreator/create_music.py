import torch
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

import numpy as np

from os import listdir
from songs import *

# periods of repetition we're going to search for
HISTORY_TIMES = np.array([4, 8, 16, 32, 48, 64, 96, 128])

# time (binary coded) as additional input 
TIME_AS_INPUT_SIZE = 6

# number of voices in polyphonic sampling scheme
VOICES = 5

# Network Parameters
num_input = 12 + TIME_AS_INPUT_SIZE         # dimension of one input at moment
num_hidden_local = 100                      # dimension of LSTM for local dependencies 
num_hidden_read = 100                       # dimension of LSTM for reading from history
num_hidden_aggreg = 130                     # dimension of aggregation layer
num_hidden_voicegen = 100                   # dimension of voices generation layer
num_output = 12                             # output dimension for each voice

num_hidden_decoder = 100                    # dimension of decoder LSTM
num_decoder_output = 88                     # dimension of decoder output
num_decoder_rbm_hidden = 36                 # dimension of decoder rbm hidden layer
rbm_k = 1                                   # Gibbs sampling iterations in decoder

INDICES = Variable(torch.LongTensor(HISTORY_TIMES - 1))

class HistoryReader(nn.Module):
    '''Soft attention module'''
    def __init__(self):
        super(HistoryReader, self).__init__()
        
        self.read_lstm = nn.LSTM(num_input, num_hidden_read)        
        self.read_linear = nn.Linear(num_hidden_read, len(HISTORY_TIMES))
    
    def init_hidden(self, batch_size, history_init=None):
        self.hidden = (Variable(torch.zeros(1, batch_size, num_hidden_read)),
                       Variable(torch.zeros(1, batch_size, num_hidden_read)))
        
        # storing history of sequence, requires initialization
        self.history = history_init        
    
    def forward(self, x):        
        # getting coeff of weighted sum
        read_index, self.hidden = self.read_lstm(x, self.hidden)                
        read_index = F.softmax(self.read_linear(read_index), dim=2)
        self.read_index = read_index.data[0].numpy()        
        
        # updating history and selecting only ones with potential music periods
        self.history = torch.cat([x[0][:, None, :num_output], self.history[:, :-1]], dim=1)
        variants = torch.index_select(self.history, 1, INDICES)
        
        # calculating weighted sum
        read = torch.bmm(read_index[0,:,None], variants).squeeze(1)       
        
        return read[None]
        
class PolyphonySampler(nn.Module):
    '''Voice-based polyphony sampler'''
    def __init__(self):
        super(PolyphonySampler, self).__init__()
        
        # all voices are lstms, parameters shared
        self.lstm = nn.LSTM(num_hidden_aggreg + 2*num_output, num_hidden_voicegen)
        self.linear = nn.Linear(num_hidden_voicegen, 2*num_output)
        
    def init_hidden(self, batch_size):        
        self.hidden = []
        for i in range(VOICES):
            self.hidden.append((Variable(torch.zeros(1, batch_size, num_hidden_voicegen)),
                                Variable(torch.zeros(1, batch_size, num_hidden_voicegen))))
    
    def forward(self, x, next_x=None):
        # for storing decisions, which notes will play and which will not, and all probabilities
        sampled_notes = torch.zeros(1, x.size()[1], num_output)        
        sample_p = Variable(torch.zeros(1, x.size()[1], num_output))
        neg_sample_p = Variable(torch.ones(1, x.size()[1], num_output))
                                
        banned_notes = torch.zeros(1, x.size()[1], num_output)       
        ban_p = Variable(torch.zeros(1, x.size()[1], num_output))
        neg_ban_p = Variable(torch.ones(1, x.size()[1], num_output))
        
        # for visualisation
        self.voice_distributions = []
        self.voice_decisions = []
        
        for i in range(VOICES):
            # forward pass
            all_input = torch.cat([x, Variable(sampled_notes), Variable(banned_notes)], dim=2)
            out, self.hidden[i] = self.lstm(all_input, self.hidden[i])
            out = self.linear(out)            
            
            # outputs for notes, decisions for which is already made, must be zero
            coeff = (1 - torch.cat([sampled_notes, sampled_notes], dim=2)) * \
                    (1 - torch.cat([banned_notes, banned_notes], dim=2))
            out = Variable(coeff) * torch.exp(out)                       
            out = out / out.sum(2)[:,:,None]
            
            # storing the result
            self.voice_distributions.append(out.data[0].numpy())
            
            # probability to sample note is probability to sample it in previous voices plus to sample it in current voice
            sample_p = sample_p + neg_sample_p * out[:,:,:num_output]
            neg_sample_p = neg_sample_p * (1 - out[:,:,:num_output])  # probability of NOT to sample note
            
            # same thing for banning note
            ban_p = ban_p + neg_ban_p * out[:,:,num_output:]
            neg_ban_p = neg_ban_p * (1 - out[:,:,num_output:])
            
            # making decision (sampling)
            sample = torch.LongTensor(x.size()[1], 2*num_output).zero_()
            sample.scatter_(1, torch.multinomial(out.squeeze(0).data, 1), 1)
            
            self.voice_decisions.append(sample.numpy())
            
            # we require the ground truth as input to voices during learning phase
            if self.training:
                sample = torch.cat([(sample[:,:num_output] + sample[:,num_output:]) * next_x,
                                    (sample[:,:num_output] + sample[:,num_output:]) * (1 - next_x)], dim=1)
            
            # adding decision to final answer
            sampled_notes[0] += sample[:,:num_output].float()
            banned_notes[0]  += sample[:,num_output:].float()
        
        return sampled_notes, sample_p*(1 - ban_p)
        
import itertools
def time_generator():
    '''discrete time'''
    times = [np.array(t) for t in itertools.product([0, 1], repeat=TIME_AS_INPUT_SIZE)]
    t = 0
    
    while True:
        yield torch.FloatTensor(times[t])
        t = (t + 1) % len(times)

class Model(nn.Module):
    '''generator
    consists of parallel LSTM and HistoryUser as first layer and LSTM as second layer
    output is sent to polyphonic sampler'''
    def __init__(self):
        super(Model, self).__init__()
        
        self.local_lstm = nn.LSTM(num_input, num_hidden_local)
        self.history_reader = HistoryReader()
        self.aggregation_lstm = nn.LSTM(num_output + num_hidden_local, num_hidden_aggreg)
        self.sampler = PolyphonySampler()
        
        self.init_hidden(1, None)
        
    def init_hidden(self, batch_size, history_init): 
        self.timer = time_generator()
        
        self.local_hidden = (Variable(torch.zeros(1, batch_size, num_hidden_local)),
                             Variable(torch.zeros(1, batch_size, num_hidden_local)))
        
        self.history_reader.init_hidden(batch_size, history_init)
        
        self.aggreg_hidden = (Variable(torch.zeros(1, batch_size, num_hidden_aggreg)),
                             Variable(torch.zeros(1, batch_size, num_hidden_aggreg)))
        
        self.sampler.init_hidden(batch_size)
    
    def forward(self, x, next_x=None):            
        inp = torch.cat([x, Variable(self.timer.__next__())[None, None].repeat(1, x.size()[1], 1)], dim=2)
        
        local_out, self.local_hidden = self.local_lstm(inp, self.local_hidden)            
        read = self.history_reader(inp)     
        
        out, self.aggreg_hidden = self.aggregation_lstm(torch.cat([local_out, read], dim=2), self.aggreg_hidden)
        
        return self.sampler(out, next_x)
        
class Decoder(nn.Module):
    '''decoder and velocity generator'''
    def __init__(self):
        super(Decoder, self).__init__()
        
        #LSTM-RBM as decoder
        self.decoder_lstm = nn.LSTM(num_output + num_decoder_output, num_hidden_decoder)
        self.v_bias_linear = nn.Linear(num_hidden_decoder, num_decoder_output) 
        self.h_bias_linear = nn.Linear(num_hidden_decoder, num_decoder_rbm_hidden)      
        
        #stationar parameter of RBM
        self.W = nn.Parameter(torch.randn(num_decoder_rbm_hidden, num_decoder_output)*1e-2)
        
        #velocity generated by LSTM
        self.velocity_lstm = nn.LSTM(num_output + num_decoder_output, num_hidden_decoder)  
        self.velocity_linear = nn.Linear(num_hidden_decoder, num_decoder_output)   
        
        self.init_hidden(1)
        
    def init_hidden(self, batch_size):        
        self.decoder_hidden = (Variable(torch.zeros(1, batch_size, num_hidden_decoder)),
                               Variable(torch.zeros(1, batch_size, num_hidden_decoder)))
        self.velocity_hidden = (Variable(torch.zeros(1, batch_size, num_hidden_decoder)),
                               Variable(torch.zeros(1, batch_size, num_hidden_decoder)))
    
    # so it was done in one of rbm realisations...
    # seems legit, though akward.
    def sample_from_p(self, p):
        return F.relu(torch.sign(p - Variable(torch.rand(p.size()))))
    
    # for optimization during learning
    def free_energy(self, v, v_bias, h_bias):
        vbias_term = (v * v_bias).sum(2)
        hidden_term = (v.bmm(self.W.t()[None]) + h_bias).exp().add(1).log().sum(2)
        return (-hidden_term - vbias_term).mean()
    
    def forward(self, x, prev_x_decoded):            
        inp = torch.cat([x, prev_x_decoded], dim=2)
        
        out, self.decoder_hidden = self.decoder_lstm(inp, self.decoder_hidden) 
        vel, self.velocity_hidden = self.velocity_lstm(inp, self.velocity_hidden)
        
        return F.sigmoid(self.velocity_linear(vel)), self.v_bias_linear(out), self.h_bias_linear(out)
    
    # Gibbs sampling from RBM
    def sample(self, _v, v_bias, h_bias):
        v = _v
        
        for _ in range(rbm_k):
            p_h = F.sigmoid(v.bmm(self.W.t()[None]) + h_bias)
            h = self.sample_from_p(p_h)
            
            p_v = F.sigmoid(h.bmm(self.W[None]) + v_bias)
            v = self.sample_from_p(p_v)
        return v, p_v
        
def sample(model, decoder, start, decoder_start, time_limit):
    '''generation from model'''
    
    # initialization
    model.init_hidden(1, Variable(torch.zeros(1, int(HISTORY_TIMES.max()), num_output)))
    decoder.init_hidden(1)
    model.eval()
    decoder.eval()
    
    # forward pass through seed
    sample = [start[0]]
    decoded_sample = [decoder_start[0] / 128.]
    
    for t in range(len(start)-1):
        inp = Variable(torch.FloatTensor(start[t])[None, None])
        next_notes, _ = model(inp)
        
        decoder_inp = Variable(torch.FloatTensor(start[t+1])[None, None]), \
                      Variable(torch.FloatTensor(decoder_start[t+1] / 128.)[None, None])
        decoder(*decoder_inp)
        
        sample.append(start[t+1])
        decoded_sample.append(decoder_start[t+1] / 128.)
    
    next_notes = torch.FloatTensor(start[-1][None, None])
    
    # generation cycle
    while len(sample) < time_limit:
        # in 12-notes representation
        next_notes, _ = model(Variable(next_notes))        
        sample.append(next_notes[0][0].numpy())
        
        # decoding
        prev_decoded = Variable(torch.FloatTensor((decoded_sample[-1] > 0).astype(np.float32))[None, None])
        velocity, v_bias, h_bias = decoder(Variable(next_notes), prev_decoded)
        next_decoded, _ = decoder.sample(prev_decoded, v_bias, h_bias)
        
        # generating velocity and applying 12-notes mask
        mask = np.tile(sample[-1], (1 + num_decoder_output // num_output))[:num_decoder_output]
        velocity = velocity[0][0].data.numpy()
        velocity[np.logical_not(mask * next_decoded[0][0].data.numpy())] = 0
        decoded_sample.append(velocity)
        
    return np.array(sample), (128*np.array(decoded_sample)).astype(int)
    
def compress(song):
    '''compressing in 12-notes representation'''
    compressed = song[:, :12] > 0
    for i in range(1,7):
        compressed = np.logical_or(compressed, song[:, 12*i:12*i+12] > 0)            
    return compressed
    
# loading model
model = Model()
decoder = Decoder()

model.load_state_dict(torch.load("Greats - model.pt"))
decoder.load_state_dict(torch.load("Greats - decoder.pt"))

seeds = np.load("seeds.npy")

seed = seeds[np.random.randint(0, len(seeds))]
cgen, gen = sample(model, decoder, compress(seed).astype(np.float32), seed.astype(np.float32), 256)

Song(gen.astype(int), finished=True).save_file("one more sample!")
